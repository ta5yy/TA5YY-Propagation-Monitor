# Propagation Monitor — Raspberry Pi 4 / Pi 5 — v1.1

**Geliştiren: TA5YY.** Arayüzde TA5YY imzası görünür; kullanıcı istasyonu ayrı olarak kurulumda belirlenir.

## Kurulum
1. 64-bit Debian/Raspberry Pi OS ve Docker Engine + Compose gereklidir.
2. ZIP'i masaüstüne çıkarın ve klasöre girin.
3. `chmod +x kur.sh` ardından `sudo ./kur.sh` çalıştırın.
4. Kendi çağrı işaretinizi, locator bilginizi ve 1024-65535 arası portu girin.
5. Terminalde yazan `http://PI_IP:PORT` adresini yerel ağdan açın.
6. `sudo docker compose ps` ile kontrol edin.

**Önemli:** `sudo` Docker erişimi için kullanılır; kurulum betiği konteynerlerin gerçek kullanıcı UID/GID'siyle çalışmasını ve `data/` yazma iznini sağlar. `chmod 777` gerekmiyor.

## Gereksinimler ve sınırlar
- Docker kurulumu sistemde değişiklik yapar. Mevcut qFT8 gibi yazılımların çalışmasını ayrıca doğrulayın.
- PSK Reporter'a veri gönderen bir yazılım gerekir; dashboard RF sinyali çözmez.
- MQTT canlı akışında kaçırılan geçmiş raporlar otomatik tamamlanmaz.
- Harita katmanı internet gerektirir. Uygulamada oturum açma yoktur; portu internete açmayın.
- Veritabanı `data/reports.db` dosyasında saklanır; bu klasörü paylaşmayın.
- Paket boş veriyle dağıtılır; TA5YY kişisel logları, çağrı kayıtları, IP ve parolaları içermez.

## Yönetim
- Durum: `sudo docker compose ps`
- Log: `sudo docker compose logs --tail=30 dashboard`
- Durdur: `sudo docker compose down`
- Başlat: `sudo docker compose up -d`
- Farklı istasyon için eski `data/` verilerini yeni istasyona taşımayın.
