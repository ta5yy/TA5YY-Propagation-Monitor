import re
import hashlib
import json
from datetime import datetime, timezone

FIELD = re.compile(rb'<([A-Za-z0-9_]+):(\d+)(?::[^>]*)?>', re.I)

def parse_adif(raw):
    if isinstance(raw, str):
        raw = raw.encode("utf-8")

    start = raw.lower().find(b"<eoh>")
    if start >= 0:
        raw = raw[start + 5:]

    for part in re.split(rb'<eor\s*>', raw, flags=re.I):
        fields = {}
        pos = 0

        while True:
            match = FIELD.search(part, pos)
            if not match:
                break

            length = int(match.group(2))
            if length > 1000000:
                raise ValueError("ADIF alani cok buyuk")

            begin = match.end()
            end = begin + length

            if end > len(part):
                raise ValueError("Eksik ADIF alani")

            name = match.group(1).decode("ascii").upper()
            fields[name] = part[begin:end].decode(
                "utf-8", "replace"
            ).strip()
            pos = end

        if fields.get("CALL") and fields.get("QSO_DATE"):
            yield fields

def convert_qso(fields, source="Wavelog"):
    call = fields["CALL"].upper()
    date = fields["QSO_DATE"]
    time = fields.get("TIME_ON", "000000")
    time = time.ljust(6, "0")[:6]

    stamp = datetime.strptime(
        date + time, "%Y%m%d%H%M%S"
    ).replace(tzinfo=timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )

    def frequency():
        try:
            return float(fields.get("FREQ", "0"))
        except ValueError:
            return 0.0

    freq = frequency()

    identity = {
        "call": call,
        "date": date,
        "time": time,
        "band": fields.get("BAND", "").upper(),
        "mode": fields.get("MODE", "").upper(),
        "submode": fields.get("SUBMODE", "").upper(),
        "station": fields.get("STATION_CALLSIGN", "").upper(),
    }

    qso_id = "qso:" + hashlib.sha256(
        json.dumps(identity, sort_keys=True).encode()
    ).hexdigest()

    return (
        qso_id,
        stamp,
        call,
        fields.get("MODE", "").upper(),
        fields.get("SUBMODE", "").upper(),
        fields.get("BAND", ""),
        freq,
        fields.get("RST_SENT", ""),
        fields.get("RST_RCVD", ""),
        fields.get("GRIDSQUARE", "").upper(),
        fields.get("MY_GRIDSQUARE", "").upper(),
        fields.get("COUNTRY", ""),
        source,
        json.dumps(fields, ensure_ascii=False),
    )

def export_adif(records):
    output = [
        "ADIF Export - Station Propagation Monitor",
        "<ADIF_VER:5>3.1.0",
        "<EOH>",
        "",
    ]

    for fields in records:
        parts = []
        for name, value in fields.items():
            value = str(value)
            length = len(value.encode("utf-8"))
            parts.append(f"<{name}:{length}>{value}")

        output.append("".join(parts) + "<EOR>")

    return "\n".join(output).encode("utf-8")
