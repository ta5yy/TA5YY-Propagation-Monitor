import os,re,json,sqlite3,hashlib,datetime,html
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
from qso_adif import parse_adif,convert_qso,export_adif
DB='/data/reports.db'; IMPORT='/imports'; CALLSIGN=os.environ['STATION_CALLSIGN'].upper(); LOCATOR=os.environ['STATION_LOCATOR'].upper()
FIELDS=re.compile(rb'<([A-Za-z0-9_]+):(\d+)(?::[^>]*)?>',re.I)
def records(raw):
    start=raw.lower().find(b'<eoh>')
    if start>=0: raw=raw[start+5:]
    for part in re.split(rb'<eor>',raw,flags=re.I):
        d={}; pos=0
        while True:
            m=FIELDS.search(part,pos)
            if not m:break
            length=int(m.group(2)); value=part[m.end():m.end()+length]
            d[m.group(1).decode().upper()]=value.decode('utf-8','replace').strip();pos=m.end()+length
        if d.get('CALL') and d.get('QSO_DATE'):yield d

def setup():
    os.makedirs('/data',exist_ok=True)
    with sqlite3.connect(DB) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS qsos (id TEXT PRIMARY KEY, timestamp TEXT, call TEXT, mode TEXT, submode TEXT, band TEXT, freq REAL, rst_sent TEXT, rst_rcvd TEXT, grid TEXT, mygrid TEXT, country TEXT, source TEXT, adif TEXT)''')
        c.execute('CREATE TABLE IF NOT EXISTS spots(id TEXT PRIMARY KEY, timestamp TEXT, direction TEXT, call TEXT, reporter TEXT, mode TEXT, freq REAL, band TEXT, snr INTEGER, distance REAL, grid TEXT, mygrid TEXT, country TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS imports(name TEXT PRIMARY KEY, size INTEGER, inserted INTEGER, processed TEXT)')

def band(freq):
    if not freq:return 'Unknown'
    for lo,hi,b in [(1.8,2,'160m'),(3.5,4,'80m'),(5.0,5.5,'60m'),(7,7.3,'40m'),(10.1,10.15,'30m'),(14,14.35,'20m'),(18.068,18.168,'17m'),(21,21.45,'15m'),(24.89,24.99,'12m'),(28,29.7,'10m'),(50,54,'6m'),(144,148,'2m')]:
        if lo<=freq<=hi:return b
    return 'Other'
def ingest(name,raw):
    inserted=0
    with sqlite3.connect(DB) as c:
        for d in records(raw):
            direction='TX' if d.get('CALL','').upper()==CALLSIGN else 'RX' if d.get('OPERATOR','').upper()==CALLSIGN else 'OTHER'
            if direction=='OTHER':continue
            ts=d['QSO_DATE']+d.get('TIME_ON','000000').ljust(6,'0')[:6]
            try: stamp=datetime.datetime.strptime(ts,'%Y%m%d%H%M%S').isoformat()+'Z'
            except ValueError:continue
            try: freq=float(d.get('FREQ','0'))
            except ValueError:freq=0
            def number(key,typ):
                try:return typ(d.get(key,''))
                except (ValueError,TypeError):return None
            # Keep all original fields in key: reports that share time/call may still be distinct.
            key=hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest()
            vals=(key,stamp,direction,d.get('CALL',''),d.get('OPERATOR',''),d.get('MODE',''),freq,band(freq),number('APP_PSKREP_SNR',int),number('DISTANCE',float),d.get('GRIDSQUARE',''),d.get('MY_GRIDSQUARE',''),d.get('COUNTRY',''))
            inserted+=c.execute('INSERT OR IGNORE INTO spots VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',vals).rowcount
        c.execute('INSERT OR REPLACE INTO imports VALUES (?,?,?,?)',(name,len(raw),inserted,datetime.datetime.now(datetime.timezone.utc).isoformat()))
    return inserted

def maidenhead(loc):
    loc=loc.strip().upper()
    if len(loc)<4:return None
    try:
        lon=(ord(loc[0])-65)*20-180+int(loc[2])*2+1
        lat=(ord(loc[1])-65)*10-90+int(loc[3])*1+0.5
        if len(loc)>=6 and loc[4:6].isalpha():
            lon+=(ord(loc[4])-65)*(2/24)+(2/24)/2-1
            lat+=(ord(loc[5])-65)*(1/24)+(1/24)/2-0.5
        return [round(lat,4),round(lon,4)]
    except (ValueError,IndexError):return None

def station_distance_km(grid):
    # Configured station locator
    from math import radians, sin, cos, asin, sqrt

    a=maidenhead(LOCATOR)
    b=maidenhead(grid or '')

    if not a or not b:
        return None

    lat1,lon1=map(radians,a)
    lat2,lon2=map(radians,b)

    dlat=lat2-lat1
    dlon=lon2-lon1

    h=sin(dlat/2)**2+cos(lat1)*cos(lat2)*sin(dlon/2)**2
    h=min(1.0,max(0.0,h))

    return round(6371.0088*2*asin(sqrt(h)),1)



# STATION DXCC country lookup - CTY.DAT
_STATION_PREFIXES={}
_STATION_EXACT={}

def station_load_cty():
    from pathlib import Path

    path=Path('/app/dxcc/cty.dat')
    if not path.is_file():
        print('STATION: CTY.DAT bulunamadi')
        return

    country=None

    for raw in path.read_text(encoding='latin-1').splitlines():
        line=raw.strip()
        if not line:
            continue

        if not raw[0].isspace() and line.endswith(':'):
            fields=line.split(':')
            if len(fields)>=8:
                country=fields[0].strip()
            continue

        if country is None:
            continue

        for item in line.rstrip(';').split(','):
            item=item.strip().upper()
            if not item:
                continue

            for char in ('(', '[', '<', '{', '~'):
                item=item.split(char,1)[0]

            if item.startswith('='):
                _STATION_EXACT[item[1:]]=country
            elif item:
                _STATION_PREFIXES[item]=country

    print('STATION DXCC:',len(_STATION_PREFIXES),
          'prefixes,',len(_STATION_EXACT),'exact calls')

def station_country(call,existing=None):
    if existing and str(existing).strip():
        return existing

    call=(call or '').strip().upper()
    if not call:
        return None

    if call in _STATION_EXACT:
        return _STATION_EXACT[call]

    matches=[
        (len(prefix),name)
        for prefix,name in _STATION_PREFIXES.items()
        if call.startswith(prefix)
    ]

    return max(matches)[1] if matches else None

station_load_cty()


PAGE=open('/app/dashboard-v1.1.html',encoding='utf-8').read().replace('__CALLSIGN__',html.escape(CALLSIGN))
class Handler(BaseHTTPRequestHandler):
    def respond(self,data,content_type='application/json'):
        body=data.encode();self.send_response(200);self.send_header('Content-Type',content_type+'; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_POST(self):
        if urlparse(self.path).path!='/api/qso/upload':
            return self.send_error(404)
        try:
            length=int(self.headers.get('Content-Length','0'))
        except ValueError:
            return self.send_error(400,'Invalid length')
        if length<=0 or length>20*1024*1024:
            return self.send_error(413,'ADIF size limit 20 MB')
        raw=self.rfile.read(length)
        try:
            parsed=list(parse_adif(raw))
            if not parsed:
                return self.send_error(400,'No QSO records')
            rows=[convert_qso(d) for d in parsed]
        except (ValueError,KeyError) as e:
            return self.send_error(400,str(e))
        with sqlite3.connect(DB,timeout=30) as c:
            inserted=0
            for row in rows:
                inserted+=c.execute(
                    'INSERT OR IGNORE INTO qsos VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    row
                ).rowcount
        return self.respond(json.dumps({
            'received':len(rows),
            'inserted':inserted,
            'duplicates':len(rows)-inserted
        }))

    def do_GET(self):
        p=urlparse(self.path)
        if p.path=='/':return self.respond(PAGE,'text/html')
        if p.path=='/api/qso/export':
            with sqlite3.connect(DB) as c:
                rows=c.execute('SELECT adif FROM qsos ORDER BY timestamp')
                data=export_adif([json.loads(r[0]) for r in rows])
            self.send_response(200)
            self.send_header('Content-Type','application/octet-stream')
            self.send_header('Content-Disposition','attachment; filename="Station-QSO.adif"')
            self.send_header('Content-Length',str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if p.path=='/api/qso':
            with sqlite3.connect(DB) as c:
                rows=c.execute(
                    'SELECT timestamp,call,mode,submode,band,freq,grid,country FROM qsos ORDER BY timestamp DESC LIMIT 10000'
                )
                result=[]
                for ts,call,mode,submode,b,freq,grid,country in rows:
                    result.append(dict(
                        timestamp=ts,call=call,mode=mode,
                        submode=submode,band=b,freq=freq,
                        grid=grid,country=country,
                        point=maidenhead(grid)
                    ))
            return self.respond(json.dumps({
                'total':len(result),'qsos':result
            }))

        with sqlite3.connect(DB) as c:
            if p.path=='/api/live-version':
                spot=c.execute(
                    'SELECT COUNT(*),MAX(rowid) FROM spots'
                ).fetchone()
                qso=c.execute(
                    'SELECT COUNT(*),MAX(rowid) FROM qsos'
                ).fetchone()

                return self.respond(json.dumps({
                    'spots':spot[0],
                    'spots_version':spot[1] or 0,
                    'qsos':qso[0],
                    'qsos_version':qso[1] or 0
                }))

            if p.path=='/api/options':
                return self.respond(json.dumps({'bands':[x[0] for x in c.execute('SELECT DISTINCT band FROM spots ORDER BY band')],'modes':[x[0] for x in c.execute('''
SELECT CASE WHEN UPPER(mode) IN ('SSB','USB','LSB') THEN 'SSB' ELSE mode END
FROM spots WHERE mode IS NOT NULL AND mode!=''
UNION
SELECT CASE WHEN UPPER(mode) IN ('SSB','USB','LSB') THEN 'SSB' ELSE mode END
FROM qsos WHERE mode IS NOT NULL AND mode!=''
UNION
SELECT CASE WHEN UPPER(submode) IN ('SSB','USB','LSB') THEN 'SSB' ELSE submode END
FROM qsos WHERE submode IS NOT NULL AND submode!=''
ORDER BY 1
''')]}))
            if p.path=='/api/spots':
                q=parse_qs(p.query);get=lambda k:q.get(k,['all'])[0]
                where=[];args=[]

                custom_start=None
                custom_end=None
                if get('custom_date')!='all':
                    try:
                        day=datetime.date.fromisoformat(get('custom_date'))
                        start_time=datetime.time.fromisoformat(get('custom_start'))
                        end_time=datetime.time.fromisoformat(get('custom_end'))
                        if start_time>=end_time:
                            raise ValueError('Baslangic bitisten once olmali')

                        tr=datetime.timezone(datetime.timedelta(hours=3))
                        custom_start=datetime.datetime.combine(
                            day,start_time,tzinfo=tr
                        ).astimezone(datetime.timezone.utc)
                        custom_end=datetime.datetime.combine(
                            day,end_time,tzinfo=tr
                        ).astimezone(datetime.timezone.utc)
                    except ValueError:
                        return self.respond(
                            json.dumps({'error':'Gecersiz tarih veya saat araligi'}),
                            400
                        )

                for field in ('direction','band','mode'):
                    if get(field)!='all':
                        if field=='mode' and get(field).upper()=='SSB':
                            where.append("UPPER(mode) IN ('SSB','USB','LSB')")
                        else:
                            where.append(field+'=?')
                            args.append(get(field))
                if custom_start is not None:
                    where.append('timestamp>=? AND timestamp<?')
                    args.extend([
                        custom_start.strftime('%Y-%m-%dT%H:%M:%SZ'),
                        custom_end.strftime('%Y-%m-%dT%H:%M:%SZ')
                    ])
                elif get('period')!='all':
                    try:minutes=int(get('period'));cutoff=datetime.datetime.now(datetime.timezone.utc)-datetime.timedelta(minutes=minutes);where.append('timestamp>=?');args.append(cutoff.strftime('%Y-%m-%dT%H:%M:%SZ'))
                    except ValueError:pass
                station=q.get('station',[''])[0].strip().upper()
                if station:
                    where.append('UPPER(call) LIKE ?')
                    args.append('%'+station+'%')
                w=(' WHERE '+' AND '.join(where)) if where else ''
                total,tx,rx=c.execute("SELECT COUNT(*),SUM(CASE WHEN direction='TX' THEN 1 ELSE 0 END),SUM(CASE WHEN direction='RX' THEN 1 ELSE 0 END) FROM spots"+w,args).fetchone()
                rows=c.execute('SELECT timestamp,direction,call,mode,band,snr,grid,mygrid,freq,country,distance FROM spots'+w+' ORDER BY timestamp DESC LIMIT 10000',args)
                spots=[]
                for stamp,direction,call,mode,b,snr,grid,mygrid,freq,country,distance in rows:
                    point=maidenhead(grid)
                    if point:spots.append(dict(timestamp=stamp,direction=direction,call=call,mode='SSB' if (mode or '').upper() in ('SSB','USB','LSB') else mode,band=b,snr=snr,grid=grid,mygrid=mygrid,freq=freq,country=station_country(call,country),distance=station_distance_km(grid),point=point))
                # Wavelog QSO records are stored separately from PSK spots.
                qso_where=[]
                qso_args=[]

                if get('band')!='all':
                    qso_where.append('LOWER(band)=LOWER(?)')
                    qso_args.append(get('band'))

                if get('mode')!='all':
                    if get('mode').upper()=='SSB':
                        qso_where.append(
                            "(UPPER(mode) IN ('SSB','USB','LSB') "
                            "OR UPPER(submode) IN ('SSB','USB','LSB'))"
                        )
                    else:
                        qso_where.append(
                            '(UPPER(mode)=UPPER(?) OR UPPER(submode)=UPPER(?))'
                        )
                        qso_args.extend([get('mode'),get('mode')])

                if custom_start is not None:
                    qso_where.append('timestamp>=? AND timestamp<?')
                    qso_args.extend([
                        custom_start.strftime('%Y-%m-%dT%H:%M:%SZ'),
                        custom_end.strftime('%Y-%m-%dT%H:%M:%SZ')
                    ])
                elif get('period')!='all':
                    try:
                        minutes=int(get('period'))
                        cutoff=datetime.datetime.now(
                            datetime.timezone.utc
                        )-datetime.timedelta(minutes=minutes)
                        qso_where.append('timestamp>=?')
                        qso_args.append(
                            cutoff.strftime('%Y-%m-%dT%H:%M:%SZ')
                        )
                    except ValueError:
                        pass

                if station:
                    qso_where.append('UPPER(call) LIKE ?')
                    qso_args.append('%'+station+'%')

                qso_sql=(' WHERE '+' AND '.join(qso_where)) if qso_where else ''

                # QSO is independent of PSK TX/RX direction.
                if get('direction')=='all':
                    qso_rows=c.execute(
                        'SELECT timestamp,call,mode,submode,band,grid,freq,country '
                        'FROM qsos'+qso_sql+' ORDER BY timestamp DESC LIMIT 10000',
                        qso_args
                    )

                    for stamp,call,mode,submode,b,grid,freq,country in qso_rows:
                        point=maidenhead(grid or '')
                        if point:
                            spots.append(dict(
                                timestamp=stamp,
                                direction='QSO',
                                call=call,
                                mode='SSB' if (submode or mode or '').upper() in ('SSB','USB','LSB') else (submode or mode),
                                band=b,
                                snr=None,
                                grid=grid,
                                mygrid='',
                                freq=freq,
                                country=station_country(call,country),
                                distance=station_distance_km(grid),
                                point=point
                            ))

                qso_count=sum(
                    1 for item in spots
                    if item['direction']=='QSO'
                )
                return self.respond(json.dumps({
                    'total':total+qso_count,
                    'tx':tx or 0,
                    'rx':rx or 0,
                    'qso':qso_count,
                    'spots':spots
                }))
        self.send_error(404)
if __name__=='__main__':
    setup()
    for name in os.listdir(IMPORT) if os.path.isdir(IMPORT) else []:
        if name.lower().endswith(('.adi','.adif')):
            path=os.path.join(IMPORT,name)
            with sqlite3.connect(DB) as c: seen=c.execute('SELECT 1 FROM imports WHERE name=? AND size=?',(name,os.path.getsize(path))).fetchone()
            if not seen:
                print('Importing',name,ingest(name,open(path,'rb').read()),flush=True)
    print('Serving on 0.0.0.0:8765',flush=True)
    ThreadingHTTPServer(('0.0.0.0',8765),Handler).serve_forever()
