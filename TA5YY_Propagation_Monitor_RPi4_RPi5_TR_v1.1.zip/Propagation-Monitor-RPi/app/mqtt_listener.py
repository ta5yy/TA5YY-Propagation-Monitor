import os
import json
import sqlite3
import subprocess
import time
import datetime
import hashlib

DB = "/data/reports.db"
CALLSIGN = os.environ["STATION_CALLSIGN"].upper()

TOPICS = [
    f"pskr/filter/v2/+/+/{CALLSIGN}/#",
    f"pskr/filter/v2/+/+/+/{CALLSIGN}/#",
]

def band(freq):
    for lo, hi, name in [
        (1.8, 2, "160m"), (3.5, 4, "80m"),
        (7, 7.3, "40m"), (10.1, 10.15, "30m"),
        (14, 14.35, "20m"), (18.068, 18.168, "17m"),
        (21, 21.45, "15m"), (24.89, 24.99, "12m"),
        (28, 29.7, "10m"), (50, 54, "6m")
    ]:
        if lo <= freq <= hi:
            return name
    return "Other"

def save(d):
    sender = str(d.get("sc", "")).upper()
    receiver = str(d.get("rc", "")).upper()

    if sender == CALLSIGN:
        direction = "TX"
        other = receiver
        grid = d.get("rl", "")
        mygrid = d.get("sl", "")
    elif receiver == CALLSIGN:
        direction = "RX"
        other = sender
        grid = d.get("sl", "")
        mygrid = d.get("rl", "")
    else:
        return

    stamp = datetime.datetime.fromtimestamp(
        int(d["t"]), datetime.timezone.utc
    ).strftime("%Y-%m-%dT%H:%M:%SZ")

    freq = float(d.get("f", 0)) / 1000000
    snr = d.get("rp")
    report_id = "mqtt:" + str(d.get("sq") or hashlib.sha256(
        json.dumps(d, sort_keys=True).encode()
    ).hexdigest())

    values = (
        report_id, stamp, direction, other,
        receiver,
        d.get("md", ""), freq, d.get("b") or band(freq),
        int(snr) if snr is not None else None,
        None, grid, mygrid, ""
    )

    with sqlite3.connect(DB, timeout=15) as conn:
        result = conn.execute(
            "INSERT OR IGNORE INTO spots VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            values
        )
        if result.rowcount:
            print("KAYDEDILDI", direction, other, stamp, flush=True)

while True:
    cmd = [
        "mosquitto_sub",
        "-h", "mqtt.pskreporter.info",
        "-p", "1883",
        "-F", "%p"
    ]

    for topic in TOPICS:
        cmd += ["-t", topic]

    try:
        print("MQTT baglantisi baslatiliyor...", flush=True)
        with subprocess.Popen(
            cmd, stdout=subprocess.PIPE, text=True
        ) as process:
            for line in process.stdout:
                try:
                    save(json.loads(line))
                except Exception as error:
                    print("Kayit hatasi:", error, flush=True)
    except Exception as error:
        print("Baglanti hatasi:", error, flush=True)

    time.sleep(5)
