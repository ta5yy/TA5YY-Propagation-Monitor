#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo "Docker kurulu degil."; exit 1; }
# Docker'a root erisimi vermeden once sudo kullanarak calistirabiliriz.
if docker info >/dev/null 2>&1; then
  DOCKER=(docker)
elif sudo -n docker info >/dev/null 2>&1; then
  DOCKER=(sudo docker)
else
  echo "Docker erisim izni yok. Bu betigi 'sudo ./kur.sh' ile tekrar calistirin."
  exit 1
fi
"${DOCKER[@]}" compose version >/dev/null || { echo "Docker Compose gerekli."; exit 1; }
read -rp "Cagri isareti: " CALL
CALL=$(echo "$CALL" | tr '[:lower:]' '[:upper:]' | tr -d '[:space:]')
[[ "$CALL" =~ ^[A-Z0-9/]{3,20}$ ]] || { echo "Gecersiz cagri isareti"; exit 1; }
read -rp "Maidenhead locator (4/6/8 karakter): " GRID
GRID=$(echo "$GRID" | tr '[:lower:]' '[:upper:]' | tr -d '[:space:]')
[[ "$GRID" =~ ^[A-R]{2}[0-9]{2}([A-X]{2}([0-9]{2})?)?$ ]] || { echo "Gecersiz locator"; exit 1; }
read -rp "Web portu [8765]: " PORT
PORT=${PORT:-8765}
[[ "$PORT" =~ ^[0-9]{2,5}$ ]] && ((PORT>=1024 && PORT<=65535)) || { echo "Gecersiz port"; exit 1; }
# 'sudo ./kur.sh' ile calistirilsa da konteynerler gercek masaustu
# kullanicisinin UID/GID'siyle calisir. data/ bu kullaniciya ait olur.
if [[ ${EUID} -eq 0 && -n ${SUDO_USER:-} ]]; then
  RUN_UID=$(id -u "$SUDO_USER")
  RUN_GID=$(id -g "$SUDO_USER")
else
  RUN_UID=$(id -u)
  RUN_GID=$(id -g)
fi
mkdir -p data imports
if [[ ${EUID} -eq 0 ]]; then
  chown "$RUN_UID:$RUN_GID" data imports
fi
chmod 750 data imports
umask 077
printf 'STATION_CALLSIGN=%s\nSTATION_LOCATOR=%s\nDASHBOARD_PORT=%s\nHOST_UID=%s\nHOST_GID=%s\n' "$CALL" "$GRID" "$PORT" "$RUN_UID" "$RUN_GID" > .env
if [[ ${EUID} -eq 0 ]]; then chown "$RUN_UID:$RUN_GID" .env; fi
chmod 600 .env
"${DOCKER[@]}" compose up -d --build
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo "Dashboard: http://${IP:-RASPBERRY_PI_IP}:$PORT"
echo "Ilk raporlarin gelmesi zaman alabilir."
